#!/bin/bash

if [  -f lifekeeper-setup.conf ]; then
        source lifekeeper-setup.conf
else
        echo "$0: lifekeeper-setup.conf not found"
        exit 1
fi

export PATH=$PATH:/opt/LifeKeeper/bin

# Common setting

# Communication Path
if [ -x ./COMMON_COMMPATH.sh ]; then
	./COMMON_COMMPATH.sh precheck
	if [ $? -ne 0 ]; then exit 1; fi
	./COMMON_COMMPATH.sh create
	if [ $? -ne 0 ]; then exit 1; fi
else
	echo "./COMMON_COMMPATH.sh : can not executable."
	exit 1
fi

# check Generic LifeKeeper Settings
if [ -x ./COMMON_SETTINGS.sh ]; then
	./COMMON_SETTINGS.sh precheck
	if [ $? -ne 0 ]; then exit 1; fi
	# check Generic LifeKeeper Settings has only 'precheck'
else
	echo "./COMMON_SETTINGS.sh : can not executable."
	exit 1
fi

# DataKeeper ARK
if [ "$ARK_DATAKEEPER" = "Y" ]; then
	if [ -x ./ARK_DATAKEEPER.sh ]; then
		./ARK_DATAKEEPER.sh precheck
		if [ $? -ne 0 ]; then exit 1; fi
		./ARK_DATAKEEPER.sh create
		if [ $? -ne 0 ]; then exit 1; fi
		FS_CLASS=1
	else
		echo "./ARK_DATAKEEPER.sh : can not executable."
		exit 1
	fi
fi

# IP ARK
if [ "$ARK_IP" = "Y" ]; then
	if [ -x ./ARK_IP.sh ]; then
		./ARK_IP.sh precheck
		if [ $? -ne 0 ]; then exit 1; fi
		./ARK_IP.sh create
		if [ $? -ne 0 ]; then exit 1; fi
		IP_CLASS=1
	else
		echo "./ARK_IP.sh : can not executable."
		exit 1
	fi
fi

# EC2 ARK
if [ "$ARK_EC2" = "Y" ]; then
	if [ $IP_CLASS -ne 1 ]; then
		echo "IP Resource is not created"
		echo "check setting: 'ARK_IP=Y'"
		exit 1
	fi
	if [ -x ./ARK_EC2.sh ]; then
		./ARK_EC2.sh precheck
		if [ $? -ne 0 ]; then exit 1; fi
		./ARK_EC2.sh create
		if [ $? -ne 0 ]; then exit 1; fi
	else
		echo "./ARK_EC2.sh : can not executable."
		exit 1
	fi
fi

# Oracle Listener ARK
if [ "$ARK_ORACLE_LISTENER" = "Y" ]; then
	if [ $IP_CLASS -ne 1 ]; then
		echo "IP Resource is not created"
		echo "check setting: 'ARK_IP=Y'"
		exit 1
	fi
	if [ -x ./ARK_ORACLE_LISTENER.sh ]; then
		./ARK_ORACLE_LISTENER.sh precheck
		if [ $? -ne 0 ]; then exit 1; fi
		./ARK_ORACLE_LISTENER.sh create
		if [ $? -ne 0 ]; then exit 1; fi
		ORACLE_LISTENER_CLASS=1
	else
		echo "./ARK_ORACLE_LISTENER.sh : can not executable."
		exit 1
	fi
fi

# Oracle ARK
if [ "$ARK_ORACLE" = "Y" ]; then
	if [ $FS_CLASS -ne 1 ]; then
		echo "Filesystem Resource is not created"
		echo "check setting: 'ARK_DATAKEEPER=Y' or 'ARK_FS=Y'"
		exit 1
	fi
	if [ $ORACLE_LISTENER_CLASS -ne 1 ]; then
		echo "Oracle Listener Resource is not created"
		echo "check setting: 'ARK_ORACLE_LISTENER=Y'"
		exit 1
	fi
	if [ -x ./ARK_ORACLE.sh ]; then
		./ARK_ORACLE.sh precheck
		if [ $? -ne 0 ]; then exit 1; fi
		./ARK_ORACLE.sh create
		if [ $? -ne 0 ]; then exit 1; fi
	else
		echo "./ARK_ORACLE.sh : can not executable."
		exit 1
	fi
fi

echo "LifeKeeper setting complete."
exit 0


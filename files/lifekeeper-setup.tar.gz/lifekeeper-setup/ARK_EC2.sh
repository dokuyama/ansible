#!/bin/bash
#set -x

if [  -f lifekeeper-setup.conf ]; then
	source lifekeeper-setup.conf
else
	echo "$0: lifekeeper-setup.conf not found"
	exit 1
fi
if [ -f COMMON_LIB.sh ]; then
        source COMMON_LIB.sh
else
        echo "$0: COMMON_LIB.sh not found"
        exit 1
fi

#
# Precheck
#
precheck () {
RET=()

echo "$0: Precheck start"

# check required values
echo "checking required config values"
if [ -z "${VIP}" ]; then
        RET+=("VIP : config value is not defined.")
fi

if [ "$EC2_TYPE" = "RouteTable" ] || [ "$EC2_TYPE" = "ElasticIP" ] ; then
	: # OK
else
	RET+=("EC2_TYPE : config value is not defined.")
fi
if [ "$EC2_TYPE" = "RouteTable" ]; then
	if [ -z "$EC2_IP_RESOURCE_TAG" ]; then
		RET+=("EC2_IP_RESOURCE_TAG : config value is not defined.")
	fi
fi
if [ "$EC2_TYPE" = "ElasticIP" ]; then
	if [ -z "$EC2_ELASTIC_IP" ]; then
		RET+=("EC2_ELASTIC_IP : config value is not defined.")
	fi
	if [ -z "$EC2_DEV" ]; then
		RET+=("EC2_DEV : config value is not defined.")
	fi
fi

if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: requied config settings is missing."
	for i in "$RET[@]}" ; do echo $i ;done
        exit 1
fi
echo "done."


# check already configured
/opt/LifeKeeper/bin/lkcli resource info --tag ec2-$VIP |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$0: Tag ec2-$VIP already created. Skipping this script..."
	exit 0
fi


# check config
if [ "$EC2_TYPE" = "RouteTable" ]; then
	echo "checking aws cli ($ACTIVE_HOST)"
	aws ec2 describe-route-tables > /dev/null
	if [ $? -ne 0 ]; then
	        RET+=("AWS CLI $ACTIVE_HOST : 'aws ec2 describe-route-tables' command faild. Plase check aws cli.")
	fi
	echo "checking aws cli ($STANDBY_HOST)"
	/opt/LifeKeeper/bin/lcdremexec -d $STANDBY_HOST aws ec2 describe-route-tables > /dev/null
	if [ $? -ne 0 ]; then
	        RET+=("AWS CLI $STANDBY_HOST : 'aws ec2 describe-route-tables' command faild. Plase check aws cli.")
	fi

	echo "done."
	echo 
fi
if [ "$EC2_TYPE" = "ElasticIP" ]; then
	echo "checking aws cli ($ACTIVE_HOST)"
	aws ec2 describe-addresses --public-ips $VIP > /dev/null
	if [ $? -ne 0 ]; then
	        RET+=("AWS CLI $ACTIVE_HOST : 'aws ec2 describe-addresses --public-ips $VIP' command faild or $VIP not found. Plase check settings.")
	fi
	echo "checking aws cli ($STANDBY_HOST)"
	/opt/LifeKeeper/bin/lcdremexec -d $STANDBY_HOST aws ec2 describe-addresses --public-ips $VIP > /dev/null
	if [ $? -ne 0 ]; then
	        RET+=("AWS CLI $STANDBY_HOST : 'aws ec2 describe-addresses --public-ips $VIP' command faild or $VIP not found. Plase check settings.")
	fi

	echo "done."
	echo 
fi

# check finish
if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: Precheck completed : failed test(s):"
	for i in "$RET[@]}" ; do echo $i ;done
        exit 1
else
        echo "$0: Precheck completed"
        exit 0
fi
}
#
# Precheck end
#

#
# Create Resource
#
create () {
# check already configured (local)
/opt/LifeKeeper/bin/lkcli resource info --tag ec2-$VIP |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$ACTIVE_HOST: Tag ec2-$VIP already created. Skipping..."
else
	if [ "$EC2_TYPE" = "RouteTable" ]; then
		/opt/LifeKeeper/bin/lkcli resource create ec2 --tag ec2-$VIP --type $EC2_TYPE --ip_resource $EC2_IP_RESOURCE_TAG
		if [ $? -ne 0 ]; then
			echo "ERROR: failed command : resource create ec2 --tag ec2-$VIP --type $EC2_TYPE --ip_resource $EC2_IP_RESOURCE_TAG"
			exit 1
		fi
	fi
	if [ "$EC2_TYPE" = "ElasticIP" ]; then
		/opt/LifeKeeper/bin/lkcli resource create ec2 --tag ec2-$VIP --type $EC2_TYPE --eip $EC2_ELASTIC_IP --dev $EC2_DEV
		if [ $? -ne 0 ]; then
			echo "ERROR: failed command : resource create ec2 --tag ec2-$VIP --type $EC2_TYPE --eip $EC2_ELASTIC_IP --dev $EC2_DEV"
			exit 1
		fi
	fi
fi

# check already configured (remote)
/opt/LifeKeeper/bin/lcdremexec -d $STANDBY_HOST /opt/LifeKeeper/bin/lkcli resource info --tag ec2-$VIP |& grep 'No resource instance has tag' > /dev/null
if [ $? -ne 0 ]; then
	echo "$STANDBY_HOST: Tag ec2-$VIP already created. Skipping..."
else
	/opt/LifeKeeper/bin/lkcli resource extend ec2 --tag ec2-$VIP --dest $STANDBY_HOST
	if [ $? -ne 0 ]; then
		echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli resource extend ec2 --tag ec2-$VIP --dest $STANDBY_HOST"
		exit 1
	fi
fi

# local (ISP)
echo "Checking $ACTIVE_HOST ec2-$VIP status"
check_status ec2-$VIP ISP
# remote (OSU)
echo "Checking $STANDBY_HOST ec2-$VIP status"
check_status_remote ec2-$VIP OSU $STANDBY_HOST
}
#
# Create Resource end
#

# main run
case $1 in
	precheck) precheck ;;
	create) create ;;
	*) echo "Usage: $0 (precheck|create)" ; exit 1 ;;
esac


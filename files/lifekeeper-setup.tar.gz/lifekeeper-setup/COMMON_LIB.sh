#!/bin/bash

#
# check_status TAG STATUS
# 
check_status() {
	# ARG1 TAG NAME
	TAG=$1
	# ARG2 STATUS (ISP/OSU)
	STATUS=$2

	# setting value
	RETRY=20
	SLEEP=1

	i=0
	S_CODE=0

	while [[ $i -lt $RETRY ]] ; do
		/opt/LifeKeeper/bin/lkcli status -e |grep "$TAG"|grep $STATUS >/dev/null
		if [ $? -ne 0 ]; then
			# failed, retry
			sleep $SLEEP
		else
			S_CODE=1
			break
		fi
		i=$((i+1))
	done
	if [ $S_CODE -eq 0 ]; then
		echo "ERROR: Resource : $TAG is not Status = $STATUS"
		return 1
	else
		# status OK
		echo "OK: Resource : $TAG is Status = $STATUS"
		return 0
	fi
}

#
# check_status_remote TAG STATUS REMOTE_HOST
#
check_status_remote() {
        # ARG1 TAG NAME
        TAG=$1
        # ARG2 STATUS (ISP/OSU)
        STATUS=$2
	# REMOTE HOSTNAME
	REMOTE=$3

        # setting value
        RETRY=20
        SLEEP=1

        i=0
        S_CODE=0

        while [[ $i -lt $RETRY ]] ; do
                /opt/LifeKeeper/bin/lcdremexec -d $REMOTE /opt/LifeKeeper/bin/lkcli status -e |grep "$TAG"|grep $STATUS >/dev/null
                if [ $? -ne 0 ]; then
                        # failed, retry
                        sleep $SLEEP
                else
                        S_CODE=1
                        break
                fi
                i=$((i+1))
        done
        if [ $S_CODE -eq 0 ]; then
                echo "ERROR: Resource : $TAG is not Status = $STATUS"
                return 1
        else
                # status OK
                echo "OK: Resource : $TAG is Status = $STATUS"
                return 0
        fi
}


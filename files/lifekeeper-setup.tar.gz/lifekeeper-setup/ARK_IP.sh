#!/bin/bash
#set -x

if [  -f lifekeeper-setup.conf ]; then
	source lifekeeper-setup.conf
else
	echo "$0: lifekeeper-setup.conf not found"
	exit 1
fi
if [ -f COMMON_LIB.sh ]; then
	source COMMON_LIB.sh
else
	echo "$0: COMMON_LIB.sh not found"
	exit 1
fi

#
# Precheck
#
precheck () {
RET=()

echo "$0: Precheck start"

# check required values
echo "checking required config values"
if [ -z "${VIP}" ]; then
	RET+=("VIP : config value is not defined.")
fi
if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: requied config settings is missing."
	for i in "$RET[@]}" ; do echo $i ;done
        exit 1
fi
echo "done."


# check already configured
/opt/LifeKeeper/bin/lkcli resource info --tag ip-$VIP |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$0: Tag ip-$VIP already created. Skipping this script..."
	exit 0
fi


# check config
echo "checking usable $VIP"
ping -c 1 $VIP > /dev/null
ip nei show $VIP |grep REACHABLE > /dev/null
if [ $? -eq 0 ]; then
        RET+=("VIP : $VIP is already used.")
fi

echo "done."
echo 

# check finish
if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: Precheck completed : failed test(s):"
	for i in "$RET[@]}" ; do echo $i ;done
        exit 1
else
        echo "$0: Precheck completed"
        exit 0
fi
}
#
# Precheck end
#

#
# Create Resource
#
create () {
# check already configured (local)
/opt/LifeKeeper/bin/lkcli resource info --tag ip-$VIP |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$ACTIVE_HOST: Tag ip-$VIP already created. Skipping..."
else
	/opt/LifeKeeper/bin/lkcli resource create ip --tag ip-$VIP --ipaddr $VIP
	if [ $? -ne 0 ]; then
		echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli resource create ip --tag ip-$VIP --ipaddr $VIP"
		exit 1
	fi
fi

# check already configured (remote)
/opt/LifeKeeper/bin/lcdremexec -d $STANDBY_HOST /opt/LifeKeeper/bin/lkcli resource info --tag ip-$VIP |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$STANDBY_HOST: Tag ip-$VIP already created. Skipping..."
else
	/opt/LifeKeeper/bin/lkcli resource extend ip --tag ip-$VIP --dest $STANDBY_HOST
	if [ $? -ne 0 ]; then
		echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli resource extend ip --tag ip-$VIP --dest $STANDBY_HOST"
		exit 1
	fi
fi

# local (ISP)
echo "Checking $ACTIVE_HOST ip-$VIP status"
check_status ip-$VIP ISP
# remote (OSU)
echo "Checking $STANDBY_HOST ip-$VIP status"
check_status_remote ip-$VIP OSU $STANDBY_HOST
}
#
# Create Resource end
#

# main run
case $1 in
	precheck) precheck ;;
	create) create ;;
	*) echo "Usage: $0 (precheck|create)" ; exit 1 ;;
esac


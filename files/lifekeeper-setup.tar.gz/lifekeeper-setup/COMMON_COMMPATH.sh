#!/bin/bash

if [  -f lifekeeper-setup.conf ]; then
	source lifekeeper-setup.conf
else
	echo "$0: lifekeeper-setup.conf not found"
	exit 1
fi

#
# Precheck
#
precheck () {
RET=()

echo "$0: Precheck start"

# check required values
echo "checking required config values"
if [ -z "${ACTIVE_HOST}" ]; then
	RET+=("ACTIVE_HOST : config value is not defined.")
fi
if [ -z "${STANDBY_HOST}" ]; then
	RET+=("STANDBY_HOST : config value is not defined.")
fi
if [ -z "${ACTIVE_COMMPATH_1_IP_ADDR}" ]; then
	RET+=("ACTIVE_COMMPATH_1_IP_ADDR : config value is not defined.")
fi
if [ -z "${STANDBY_COMMPATH_1_IP_ADDR}" ]; then
	RET+=("STANDBY_COMMPATH_1_IP_ADDR : config value is not defined.")
fi
# (ACTIVE|STANDBY)_COMMPATH_2_IP_ADDR is Optional
# QW_COMMPATH_1_IP_ADDR, QW_COMMPATH_2_IP_ADDR is Optional

if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: requied config settings is missing."
	for i in "${RET[@]}" ; do echo "$i" ;done
        exit 1
fi
echo "done."

# communication path already created
# not good method...
if [ `/opt/LifeKeeper/bin/lkcli status -e |grep "$ACTIVE_COMMPATH_1_IP_ADDR/$STANDBY_COMMPATH_1_IP_ADDR" |grep ALIVE|wc -l` -eq 1 ]; then
	echo "$0: Communication path $ACTIVE_COMMPATH_1_IP_ADDR/$STANDBY_COMMPATH_1_IP_ADDR already created. Skipping..."
fi
if [ -n "${ACTIVE_COMMPATH_2_IP_ADDR}" ] && [ -n "${STANDBY_COMMPATH_2_IP_ADDR}" ]; then
	if [ `/opt/LifeKeeper/bin/lkcli status -e |grep "$ACTIVE_COMMPATH_2_IP_ADDR/$STANDBY_COMMPATH_2_IP_ADDR" |grep ALIVE|wc -l` -eq 1 ]; then
		echo "$0: Communication path $ACTIVE_COMMPATH_2_IP_ADDR/$STANDBY_COMMPATH_2_IP_ADDR already created. Skipping..."
	fi
fi
# ACTIVE1/QW1
if [ -n "${ACTIVE_COMMPATH_1_IP_ADDR}" ] && [ -n "${QW_COMMPATH_1_IP_ADDR}" ]; then
        if [ `/opt/LifeKeeper/bin/lkcli status -e |grep "$ACTIVE_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR" |grep ALIVE|wc -l` -eq 1 ]; then
                echo "$0: Communication path $ACTIVE_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR already created. Skipping..."
        fi
fi
# STANDBY1/QW1
if [ -n "${STANDBY_COMMPATH_1_IP_ADDR}" ] && [ -n "${QW_COMMPATH_1_IP_ADDR}" ]; then
        if [ `$REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli status -e |grep "$STANDBY_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR" |grep ALIVE|wc -l` -eq 1 ]; then
                echo "$0: Communication path $STANDBY_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR already created. Skipping..."
        fi
fi
# ACTIVE2/QW2
if [ -n "${ACTIVE_COMMPATH_2_IP_ADDR}" ] && [ -n "${QW_COMMPATH_2_IP_ADDR}" ]; then
        if [ `/opt/LifeKeeper/bin/lkcli status -e |grep "$ACTIVE_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR" |grep ALIVE|wc -l` -eq 1 ]; then
                echo "$0: Communication path $ACTIVE_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR already created. Skipping..."
        fi
fi
# STANDBY2/QW2
if [ -n "${STANDBY_COMMPATH_2_IP_ADDR}" ] && [ -n "${QW_COMMPATH_2_IP_ADDR}" ]; then
        if [ `$REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli status -e |grep "$STANDBY_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR" |grep ALIVE|wc -l` -eq 1 ]; then
                echo "$0: Communication path $STANDBY_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR already created. Skipping..."
        fi
fi

# check communicate
echo "checking ping response"
ping -c3 -i0.2  $ACTIVE_HOST > /dev/null
if [ $? -ne 0 ]; then
        echo "ping: $ACTIVE_HOST not responsed"
        exit 1
fi

ping -c3 -i0.2  $STANDBY_HOST > /dev/null
if [ $? -ne 0 ]; then
        echo "ping: $STANDBY_HOST not responsed"
        exit 1
fi
if [ -n $QW_HOST ]; then
	ping -c3 -i0.2  $QW_HOST > /dev/null
	if [ $? -ne 0 ]; then
        	echo "ping: $QW_HOST not responsed"
       		exit 1
	fi
fi
echo "done."
echo

# check Hostnames
echo "checking  Hostnames"
host=`hostname`
if [ $host != $ACTIVE_HOST ]; then
        RET+=("ACTIVE_HOST : $ACTIVE_HOST is not match 'hostname' command.")
fi

host=`$REMOTE_COMMAND hostname`
if [ $host != $STANDBY_HOST ]; then
        RET+=("STANDBY_HOST : $STANDBY_HOST is not match 'hostname' command.")
fi
# QW
if [ -n $QW_HOST ]; then
	host=`$QW_REMOTE_COMMAND hostname`
	if [ $host != $QW_HOST ]; then
        	RET+=("QW_HOST : $QW_HOST is not match 'hostname' command.")
	fi
fi
echo "done."
echo

# check IPs
echo "checking IP addessess"
ping -c 1 $ACTIVE_COMMPATH_1_IP_ADDR > /dev/null
if [ $? -ne 0 ]; then
        RET+=("ACTIVE_COMMPATH_1_IP_ADDR : $ACTIVE_COMMPATH_1_IP_ADDR not responsed.")
fi
ping -c 1 $ACTIVE_COMMPATH_2_IP_ADDR > /dev/null
if [ $? -ne 0 ]; then
        RET+=("ACTIVE_COMMPATH_2_IP_ADDR : $ACTIVE_COMMPATH_2_IP_ADDR not responsed.")
fi
ping -c 1 $STANDBY_COMMPATH_1_IP_ADDR > /dev/null
if [ $? -ne 0 ]; then
        RET+=("STANDBY_COMMPATH_1_IP_ADDR : $STANDBY_COMMPATH_1_IP_ADDR not responsed.")
fi
ping -c 1 $STANDBY_COMMPATH_2_IP_ADDR > /dev/null
if [ $? -ne 0 ]; then
        RET+=("STANDBY_COMMPATH_2_IP_ADDR : $STANDBY_COMMPATH_2_IP_ADDR not responsed.")
fi
# QW
if [ -n $QW_COMMPATH_1_IP_ADDR ] && [ -n $QW_COMMPATH_2_IP_ADDR ]; then
	ping -c 1 $QW_COMMPATH_1_IP_ADDR > /dev/null
	if [ $? -ne 0 ]; then
        	RET+=("QW_COMMPATH_1_IP_ADDR : $QW_COMMPATH_1_IP_ADDR not responsed.")
	fi
	ping -c 1 $QW_COMMPATH_2_IP_ADDR > /dev/null
	if [ $? -ne 0 ]; then
        	RET+=("QW_COMMPATH_2_IP_ADDR : $QW_COMMPATH_2_IP_ADDR not responsed.")
	fi
fi
echo "done."
echo


# check finish
if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: Precheck completed : failed test(s):"
	for i in "${RET[@]}" ; do echo $i ;done
        exit 1
else
        echo "$0: Precheck completed"
        exit 0
fi
}
#
# Precheck end
#

#
# Create Communication path
#
create () {
# communication path already created
if [ `/opt/LifeKeeper/bin/lkcli status -e |grep "$ACTIVE_COMMPATH_1_IP_ADDR/$STANDBY_COMMPATH_1_IP_ADDR" |grep ALIVE|wc -l` -ge 1 ]; then
	echo "$0: Communication path $ACTIVE_COMMPATH_1_IP_ADDR/$STANDBY_COMMPATH_1_IP_ADDR already created. Skipping..."
else
	/opt/LifeKeeper/bin/lkcli commpath create --laddr $ACTIVE_COMMPATH_1_IP_ADDR --raddr $STANDBY_COMMPATH_1_IP_ADDR --dest $STANDBY_HOST
	if [ $? -ne 0 ]; then
		echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli commpath create --laddr $ACTIVE_COMMPATH_1_IP_ADDR --raddr $STANDBY_COMMPATH_1_IP_ADDR --dest $STANDBY_HOST"
		exit 1
	fi
	$REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $STANDBY_COMMPATH_1_IP_ADDR --raddr $ACTIVE_COMMPATH_1_IP_ADDR --dest $ACTIVE_HOST
	if [ $? -ne 0 ]; then
		echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli commpath create --laddr $STANDBY_COMMPATH_1_IP_ADDR --raddr $ACTIVE_COMMPATH_1_IP_ADDR --dest $ACTIVE_HOST"
		exit 1
	fi
	# check communication path ALIVE
	# retry 20 times
	i=0
	while [[ $i -lt 20 ]] ; do
       		S_CODE=0
        	# not good method
        	if [ `/opt/LifeKeeper/bin/lkcli status -e |grep "$ACTIVE_COMMPATH_1_IP_ADDR/$STANDBY_COMMPATH_1_IP_ADDR" |grep ALIVE|wc -l` -eq 0 ]; then
                	# sleep
                	sleep 2
		else
			# communication path is ALIVE
			echo "Communication path $ACTIVE_COMMPATH_1_IP_ADDR/$STANDBY_COMMPATH_1_IP_ADDRcreated successful and status ALIVE"
			S_CODE=1
			break
		fi
		i=$((i+1))
	done
	if [ $S_CODE -eq 0 ]; then
		echo "ERROR: Communication path $ACTIVE_COMMPATH_1_IP_ADDR/$STANDBY_COMMPATH_1_IP_ADDR status is not ALIVE..."
		exit 1
	fi
fi

# Optional
if [ -n "${ACTIVE_COMMPATH_2_IP_ADDR}" ] && [ -n "${STANDBY_COMMPATH_2_IP_ADDR}" ]; then
	if [ `/opt/LifeKeeper/bin/lkcli status -e |grep "$ACTIVE_COMMPATH_2_IP_ADDR/$STANDBY_COMMPATH_2_IP_ADDR" |grep ALIVE|wc -l` -eq 1 ]; then
		echo "$0: Communication path $ACTIVE_COMMPATH_2_IP_ADDR/$STANDBY_COMMPATH_2_IP_ADDR already created. Skipping..."
	else
		/opt/LifeKeeper/bin/lkcli commpath create --laddr $ACTIVE_COMMPATH_2_IP_ADDR --raddr $STANDBY_COMMPATH_2_IP_ADDR --dest $STANDBY_HOST
		if [ $? -ne 0 ]; then
			echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli commpath create --laddr $ACTIVE_COMMPATH_2_IP_ADDR --raddr $STANDBY_COMMPATH_2_IP_ADDR --dest $STANDBY_HOST"
			exit 1
		fi
		$REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $STANDBY_COMMPATH_2_IP_ADDR --raddr $ACTIVE_COMMPATH_2_IP_ADDR --dest $ACTIVE_HOST
		if [ $? -ne 0 ]; then
			echo "ERROR: failed command : $REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $STANDBY_COMMPATH_2_IP_ADDR --raddr $ACTIVE_COMMPATH_2_IP_ADDR --dest $ACTIVE_HOST"
			exit 1
		fi

		# check communication path ALIVE
		# retry 20 times
		i=0
		while [[ $i -lt 20 ]] ; do
			S_CODE=0
			# not good method
			if [ `/opt/LifeKeeper/bin/lkcli status -e |grep "$ACTIVE_COMMPATH_2_IP_ADDR/$STANDBY_COMMPATH_2_IP_ADDR" |grep ALIVE|wc -l` -eq 0 ]; then
				# sleep
				sleep 2
			else
				# communication path is ALIVE
				echo "Communication path $ACTIVE_COMMPATH_2_IP_ADDR/$STANDBY_COMMPATH_2_IP_ADDR created successful and status ALIVE"
				S_CODE=1
				break
			fi
			i=$((i+1))
		done
		if [ $S_CODE -eq 0 ]; then
			echo "ERROR: Communication path $ACTIVE_COMMPATH_2_IP_ADDR/$STANDBY_COMMPATH_2_IP_ADDR status is not ALIVE..."
			exit 1
		fi
	fi
fi

# ACTIVE1/QW1
if [ -n ${ACTIVE_COMMPATH_1_IP_ADDR} ] && [ -n ${QW_COMMPATH_1_IP_ADDR} ]; then
	if [ `/opt/LifeKeeper/bin/lkcli status -e |grep "$ACTIVE_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR" |grep ALIVE|wc -l` -eq 1 ]; then
		echo "$0: Communication path $ACTIVE_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR already created. Skipping..."
	else
        	/opt/LifeKeeper/bin/lkcli commpath create --laddr $ACTIVE_COMMPATH_1_IP_ADDR --raddr $QW_COMMPATH_1_IP_ADDR --dest $QW_HOST
        	if [ $? -ne 0 ]; then
                	echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli commpath create --laddr $ACTIVE_COMMPATH_1_IP_ADDR --raddr $QW_COMMPATH_1_IP_ADDR --dest $QW_HOST"
                	exit 1
        	fi
        	$QW_REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $QW_COMMPATH_1_IP_ADDR --raddr $ACTIVE_COMMPATH_1_IP_ADDR --dest $ACTIVE_HOST
        	if [ $? -ne 0 ]; then
                	echo "ERROR: failed command : $QW_REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $QW_COMMPATH_1_IP_ADDR --raddr $ACTIVE_COMMPATH_1_IP_ADDR --dest $ACTIVE_HOST"
                	exit 1
        	fi

		# check communication path ALIVE
		# retry 20 times
        	i=0
		while [[ $i -lt 20 ]] ; do
                	S_CODE=0
			# not good method
                	if [ `/opt/LifeKeeper/bin/lkcli status -e |grep "$ACTIVE_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR" |grep ALIVE|wc -l` -eq 0 ]; then
                        	# sleep
                        	sleep 2
                	else
                        	# communication path is ALIVE
                        	echo "Communication path $ACTIVE_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR created successful and status ALIVE"
                        	S_CODE=1
                        	break
                	fi
                	i=$((i+1))
        	done
        	if [ $S_CODE -eq 0 ]; then
                	echo "ERROR: Communication path $ACTIVE_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR status is not ALIVE..."
                	exit 1
        	fi
	fi
fi

# STANDBY1/QW1
if [ -n ${STANDBY_COMMPATH_1_IP_ADDR} ] && [ -n ${QW_COMMPATH_1_IP_ADDR} ]; then
	if [ `$REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli status -e |grep "$STANDBY_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR" |grep ALIVE|wc -l` -eq 1 ]; then
		echo "$0: Communication path $STANDBY_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR already created. Skipping..."
	else
        	$REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $STANDBY_COMMPATH_1_IP_ADDR --raddr $QW_COMMPATH_1_IP_ADDR --dest $QW_HOST
        	if [ $? -ne 0 ]; then
                	echo "ERROR: failed command : $REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $STANDBY_COMMPATH_1_IP_ADDR --raddr $QW_COMMPATH_1_IP_ADDR --dest $QW_HOST"
                	exit 1
        	fi
        	$QW_REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $QW_COMMPATH_1_IP_ADDR --raddr $STANDBY_COMMPATH_1_IP_ADDR --dest $STANDBY_HOST
        	if [ $? -ne 0 ]; then
                	echo "ERROR: failed command : $QW_REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $QW_COMMPATH_1_IP_ADDR --raddr $STANDBY_COMMPATH_1_IP_ADDR --dest $STANDBY_HOST"
                	exit 1
        	fi

        	# check communication path ALIVE
        	# retry 20 times
        	i=0
        	while [[ $i -lt 20 ]] ; do
                	S_CODE=0
                	# not good method
                	if [ `$REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli status -e |grep "$STANDBY_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR" |grep ALIVE|wc -l` -eq 0 ]; then
                        	# sleep
                        	sleep 2
                	else
                        	# communication path is ALIVE
                        	echo "Communication path $STANDBY_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR created successful and status ALIVE"
                        	S_CODE=1
                        	break
                	fi
                	i=$((i+1))
        	done
        	if [ $S_CODE -eq 0 ]; then
                	echo "ERROR: Communication path $STANDBY_COMMPATH_1_IP_ADDR/$QW_COMMPATH_1_IP_ADDR status is not ALIVE..."
                	exit 1
        	fi
	fi
fi

# ACTIVE2/QW2
if [ -n ${ACTIVE_COMMPATH_2_IP_ADDR} ] && [ -n ${QW_COMMPATH_2_IP_ADDR} ]; then
	if [ `/opt/LifeKeeper/bin/lkcli status -e |grep "$ACTIVE_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR" |grep ALIVE|wc -l` -eq 1 ]; then
		echo "$0: Communication path $ACTIVE_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR already created. Skipping..."
	else
        	/opt/LifeKeeper/bin/lkcli commpath create --laddr $ACTIVE_COMMPATH_2_IP_ADDR --raddr $QW_COMMPATH_2_IP_ADDR --dest $QW_HOST
        	if [ $? -ne 0 ]; then
                	echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli commpath create --laddr $ACTIVE_COMMPATH_2_IP_ADDR --raddr $QW_COMMPATH_2_IP_ADDR --dest $QW_HOST"
                	exit 1
        	fi
        	$QW_REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $QW_COMMPATH_2_IP_ADDR --raddr $ACTIVE_COMMPATH_2_IP_ADDR --dest $ACTIVE_HOST
        	if [ $? -ne 0 ]; then
                	echo "ERROR: failed command : $QW_REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $QW_COMMPATH_2_IP_ADDR --raddr $ACTIVE_COMMPATH_2_IP_ADDR --dest $ACTIVE_HOST"
                	exit 1
        	fi

        	# check communication path ALIVE
        	# retry 20 times
        	i=0
        	while [[ $i -lt 20 ]] ; do
                	S_CODE=0
                	# not good method
                	if [ `/opt/LifeKeeper/bin/lkcli status -e |grep "$ACTIVE_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR" |grep ALIVE|wc -l` -eq 0 ]; then
                        	# sleep
                        	sleep 2
                	else
                        	# communication path is ALIVE
                        	echo "Communication path $ACTIVE_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR created successful and status ALIVE"
                        	S_CODE=1
                        	break
                	fi
                	i=$((i+1))
        	done
        	if [ $S_CODE -eq 0 ]; then
                	echo "ERROR: Communication path $ACTIVE_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR status is not ALIVE..."
                	exit 1
        	fi
	fi
fi

# STANDBY22QW2
if [ -n ${STANDBY_COMMPATH_2_IP_ADDR} ] && [ -n ${QW_COMMPATH_2_IP_ADDR} ]; then
	if [ `$REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli status -e |grep "$STANDBY_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR" |grep ALIVE|wc -l` -eq 1 ]; then
		echo "$0: Communication path $STANDBY_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR already created. Skipping..."
	else
        	$REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $STANDBY_COMMPATH_2_IP_ADDR --raddr $QW_COMMPATH_2_IP_ADDR --dest $QW_HOST
        	if [ $? -ne 0 ]; then
                	echo "ERROR: failed command : $REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $STANDBY_COMMPATH_2_IP_ADDR --raddr $QW_COMMPATH_2_IP_ADDR --dest $QW_HOST"
                	exit 1
        	fi
        	$QW_REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $QW_COMMPATH_2_IP_ADDR --raddr $STANDBY_COMMPATH_2_IP_ADDR --dest $STANDBY_HOST
        	if [ $? -ne 0 ]; then
                	echo "ERROR: failed command : $QW_REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli commpath create --laddr $QW_COMMPATH_2_IP_ADDR --raddr $STANDBY_COMMPATH_2_IP_ADDR --dest $STANDBY_HOST"
                	exit 1
        	fi

        	# check communication path ALIVE
        	# retry 20 times
        	i=0
        	while [[ $i -lt 20 ]] ; do
                	S_CODE=0
                	# not good method
                	if [ `$REMOTE_COMMAND /opt/LifeKeeper/bin/lkcli status -e |grep "$STANDBY_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR" |grep ALIVE|wc -l` -eq 0 ]; then
                        	# sleep
                        	sleep 2
                	else
                        	# communication path is ALIVE
                        	echo "Communication path $STANDBY_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR created successful and status ALIVE"
                        	S_CODE=1
                        	break
                	fi
                	i=$((i+1))
        	done
        	if [ $S_CODE -eq 0 ]; then
                	echo "ERROR: Communication path $STANDBY_COMMPATH_2_IP_ADDR/$QW_COMMPATH_2_IP_ADDR status is not ALIVE..."
                	exit 1
        	fi
	fi
fi

}
#
# Create Communication path end
#

# main run
case $1 in
	precheck) precheck ;;
	create) create ;;
	*) echo "Usage: $0 (precheck|create)" ; exit 1 ;;
esac


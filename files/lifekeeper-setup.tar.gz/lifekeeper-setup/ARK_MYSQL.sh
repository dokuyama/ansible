#!/bin/bash
#set -x

if [  -f lifekeeper-setup.conf ]; then
	source lifekeeper-setup.conf
else
	echo "$0: lifekeeper-setup.conf not found"
	exit 1
fi
if [ -f COMMON_LIB.sh ]; then
        source COMMON_LIB.sh
else
        echo "$0: COMMON_LIB.sh not found"
        exit 1
fi

#
# Precheck
#
precheck () {
RET=()

echo "$0: Precheck start"

# check required values
if [ -z "MYSQL_TAG" ]; then
	RET+=("MYSQL_TAG : config value is not defined.")
fi
if [ -z "MYSQL_CNF_DIR" ]; then
	 RET+=("MYSQL_CNF_DIR : config value is not defined.")
fi
if [ -z "MYSQL_BIN_DIR" ]; then
	RET+=("MYSQL_BIN_DIR : config value is not defined.")
fi
if [ -z "MYSQLADMIN_USER" ]; then
	RET+=("MYSQLADMIN_USER : config value is not defined.")
fi
if [ -z "MYSQLADMIN_PASSWORD" ]; then
	RET+=("MYSQL_TAG : config value is not defined.")
fi
if [ -z "MYSQL_SERVICE_NAM" ]; then
	RET+=("MYSQL_SERVICE_NAMG : config value is not defined.")
fi

if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: requied config settings is missing."
	for i in "${RET[@]}" ; do echo "$i" ;done
       exit 1
fi
echo "done."


# check already configured
/opt/LifeKeeper/bin/lkcli resource info --tag $MYSQL_TAG |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$0: Tag $MYSQL_TAG already created. Skipping this script..."
	exit 0
fi


# check config
echo "checking MySQL settings"
# check mysql running
echo "checking MySQL running..."
mysqladmin -u$MYSQLADMIN_USER -p"MYSQLADMIN_PASSWORD" ping | grep "mysqld is alive" >  /dev/null
if [ $? -eq 1 ]; then
	echo "Not running. Try startup mysql...."
	# start mysql
	service $MYSQL_SERVICE_NAME start
	if [ $? -ne 0 ]; then
		echo "MySQL startup failed"
		exit 1
	fi
fi

echo "done."
echo 

# check finish
if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: Precheck completed : failed test"
	for i in "${RET[@]}" ; do echo "$i" ;done
        exit 1
else
        echo "$0: Precheck completed"
        exit 0
fi
}
#
# Precheck end
#

#
# Create Resource
#
create () {
# check already configured
/opt/LifeKeeper/bin/lkcli resource info --tag $MYSQL_TAG |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$ACTIVE_HOST: Tag $MYSQL_TAG already created. Skipping..."
else
	/opt/LifeKeeper/bin/lkcli resource create mysql --tag $MYSQL_TAG --cnf $MYSQL_CNF_DIR --bin $MYSQL_BIN_DIR
	if [ $? -ne 0 ]; then
		echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli resource create mysql --tag $MYSQL_TAG --cnf $MYSQL_CNF_DIR --bin $MYSQL_BIN_DIR"
		exit 1
	fi
fi

# check already configured
/opt/LifeKeeper/bin/lcdremexec -d $STANDBY_HOST /opt/LifeKeeper/bin/lkcli resource info --tag $MYSQL_TAG |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$STANDBY_HOST: Tag $MYSQL_TAG already created. Skipping..."
else
	/opt/LifeKeeper/bin/lkcli resource extend mysql --tag $MYSQL_TAG --dest $STANDBY_HOST
	if [ $? -ne 0 ]; then
		echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli resource extend --tag $MYSQL_TAG --dest $STANDBY_HOST"
		exit 1
	fi
fi

# local (ISP)
echo "Checking $ACTIVE_HOST $MYSQL_TAG status"
check_status $MYSQL_TAG ISP
# remote (OSU)
echo "Checking $STANDBY_HOST $MYSQL_TAG status"
check_status_remote $MYSQL_TAG OSU $STANDBY_HOST

# Check IP ARK
# local (ISP)
echo "Checking $ACTIVE_HOST ip-$VIP status"
check_status ip-$VIP ISP
# remote (OSU)
echo "Checking $STANDBY_HOST ip-$VIP status"
check_status_remote ip-$VIP OSU $STANDBY_HOST

# change dependency
/opt/LifeKeeper/bin/lkcli dependency create --parent $MYSQL_TAG --child ip-$VIP 

}
#
# Create Resource end
#

# main run
case $1 in
	precheck) precheck ;;
	create) create ;;
	*) echo "Usage: $0 (precheck|create)" ; exit 1 ;;
esac


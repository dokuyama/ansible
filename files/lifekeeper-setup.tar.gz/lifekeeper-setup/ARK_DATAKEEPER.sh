#!/bin/bash
#set -x

if [  -f lifekeeper-setup.conf ]; then
	source lifekeeper-setup.conf
else
	echo "$0: lifekeeper-setup.conf not found"
	exit 1
fi
if [ -f COMMON_LIB.sh ]; then
        source COMMON_LIB.sh
else
        echo "$0: COMMON_LIB.sh not found"
        exit 1
fi

#
# Precheck
#
precheck () {
RET=()

echo "$0: Precheck start"

# check required values
echo "checking required config values"
if [ "$DK_HIERARCHY" = "new" ] || [ "$DK_HIERARCHY" = "existing" ]; then
	: # OK
else
	RET+=("DK_HIERARCHY : config value is invalid.")
fi
if [ "$DK_HIERARCHY" = "new" ]; then
	if [ -z "${DK_DEVICE}" ]; then
		RET+=("DK_DEVICE : config value is not defined.")
	fi
	if [ -z "${DK_FSTYPE}" ]; then
		RET+=("DK_FSTYPE : config value is not defined.")
	fi
fi
if [ "$DK_MODE" = "synchronous" ] || [ "$DK_MODE" = "asynchronous" ]; then
	: # OK
else
	RET+=("DK_MODE : config value is invalid.")
fi
if [ -z "${DK_MOUNT_POINT}" ]; then
	RET+=("DK_MOUNT_POINT : config value is not defined.")
fi
if [ -z "${DK_TAG}" ]; then
	RET+=("DK_TAG : config value is not defined.")
fi
if [ -z "${DK_COMMPATH_IP_ADDR1}" ]; then
	RET+=("DK_COMMPATH_IP_ADDR1 : config value is not defined.")
fi
if [ -z "${DK_COMMPATH_IP_ADDR1}" ]; then
	RET+=("DK_COMMPATH_IP_ADDR1 : config value is not defined.")
fi
if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: requied config settings is missing."
	for i in "${RET[@]}" ;do echo $i ;done
        exit 1
fi
echo "done."


# check already configured
/opt/LifeKeeper/bin/lkcli resource info --tag $DK_TAG |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$0: $DK_TAG already created. Skipping this script..."
	exit 0
fi


# check config
echo "checking OS settings"
if [ "$DK_HIERARCHY" = "new" ]; then
	if [ ! -e $DK_DEVICE ]; then
		RET+=("DK_DEVICE : $DK_DEVICE is not found.")
	fi
	if [ "$DK_FSTYPE" = "ext3" ] || [ "$DK_FSTYPE" = "ext4" ] || [ "$DK_FSTYPE" = "xfs" ]; then
		: # OK
	else
		RET+=("DK_FSTYPE : $DK_FSTYPE is not supported.")
	fi
	# check Partition
	/opt/LifeKeeper/lkadm/subsys/scsi/netraid/bin/getId -i $DK_DEVICE > /dev/null
	if [ $? -ne 0 ]; then
		RET+=("DK_GetID : $DK_DEVICE is not GPT or LVM partition.")
	fi
else
	# check mounted
	DK_DEVICE="`grep $DK_MOUNT_POINT /proc/mounts |awk '{print $1}'`"
	if [ -z $DK_DEVICE ] || [ ! -e $DK_DEVICE ]; then
		RET+=("DK_MOUNT_POINT : $DK_MOUNT_POINT is not mounted.")
	else
		# check Partition
		/opt/LifeKeeper/lkadm/subsys/scsi/netraid/bin/getId -i $DK_DEVICE > /dev/null
		if [ $? -ne 0 ]; then
			RET+=("DK_GetID : $DK_DEVICE is not GPT or LVM partition.")
		fi
		# FS using
		fuser -m $DK_MOUNT_POINT > /dev/null 2>&1
		if [ $? -ne 1 ]; then
			RET+=("FUSER : $DK_MOUNT_POINT filesystem in use. Pleasecheck 'fuser -m $DK_MOUNT_POINT' output.")
		fi
	fi
fi

if [ ! -d $DK_MOUNT_POINT ]; then
	RET+=("DK_MOUNT_POINT : $DK_MOUNT_POINT is not directory.")
fi
/opt/LifeKeeper/bin/lkcli status -e |grep $DK_COMMPATH_IP_ADDR1 |grep ALIVE> /dev/null
if [ $? -ne 0 ]; then
	RET+=("DK_COMMPATH_IP_ADDR1 : $DK_COMMPATH_IP_ADDR1 is not found or not ALIVE status.")
fi
/opt/LifeKeeper/bin/lkcli status -e |grep $DK_COMMPATH_IP_ADDR2 |grep ALIVE> /dev/null
if [ $? -ne 0 ]; then
	RET+=("DK_COMMPATH_IP_ADDR2 : $DK_COMMPATH_IP_ADDR2 is not found or not ALIVE status.")
fi

echo "done."
echo 

# check finish
if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: Precheck completed : failed test(s):"
	for i in "${RET[@]}" ;do echo $i ;done
        exit 1
else
        echo "$0: Precheck completed"
        exit 0
fi
}
#
# Precheck end
#

#
# Create Resource
#
create () {
# check already configured
/opt/LifeKeeper/bin/lkcli resource info --tag $DK_TAG |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$ACTIVE_HOST: Tag $DK_TAG already created. Skipping..."
else 
	DK_BITMAP="/opt/LifeKeeper/bitmap_$(echo $DK_MOUNT_POINT | sed -e 's/\//_/g')"
	if [ "$DK_HIERARCHY" = "new" ]; then
		/opt/LifeKeeper/bin/lkcli resource create dk --tag $DK_TAG --mode $DK_MODE --bitmap $DK_BITMAP --hierarchy new --device $DK_DEVICE --fstype $DK_FSTYPE --mount_point $DK_MOUNT_POINT --fstag $DK_MOUNT_POINT
		if [ $? -ne 0 ]; then
			echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli resource create dk --tag $DK_TAG --mode $DK_MODE --bitmap $DK_BITMAP --hierarchy new --device $DK_DEVICE --fstype $DK_FSTYPE --mount_point $DK_MOUNT_POINT --fstag $DK_MOUNT_POINT"
			exit 1
		fi
	fi	
	if [ "$DK_HIERARCHY" = "existing" ]; then
		# existing
		/opt/LifeKeeper/bin/lkcli resource create dk --tag $DK_TAG --mode $DK_MODE --bitmap $DK_BITMAP --hierarchy $DK_HIERARCHY --mount_point $DK_MOUNT_POINT --fstag $DK_MOUNT_POINT
		if [ $? -ne 0 ]; then
			echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli resource create dk --tag $DK_TAG --mode $DK_MODE --bitmap $DK_BITMAP --hierarchy $DK_HIERARCHY --mount_point $DK_MOUNT_POINT --fstag $DK_MOUNT_POINT"
			exit 1
		fi
	fi
fi

# check already configured (remote)
/opt/LifeKeeper/bin/lcdremexec -d $STANDBY_HOST /opt/LifeKeeper/bin/lkcli resource info --tag $DK_TAG |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$STANDBY_HOST: Tag $DK_TAG already created. Skipping..."
else 
	if [ "$DK_HIERARCHY" = "new" ]; then
		/opt/LifeKeeper/bin/lkcli resource extend dk --tag $DK_TAG --dest $STANDBY_HOST --mode $DK_MODE --laddr $DK_COMMPATH_IP_ADDR1 --raddr $DK_COMMPATH_IP_ADDR2 --fstag $DK_MOUNT_POIN
		if [ $? -ne 0 ]; then
			echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli resource extend dk --tag $DK_TAG --dest $STANDBY_HOST --mode $DK_MODE --laddr $DK_COMMPATH_IP_ADDR1 --raddr $DK_COMMPATH_IP_ADDR2 --fstag $DK_MOUNT_POIN"
			exit 1
		fi
	fi
	if [ "$DK_HIERARCHY" = "existing" ]; then
		/opt/LifeKeeper/bin/lkcli resource extend dk --tag $DK_TAG --dest $STANDBY_HOST --mode $DK_MODE --laddr $DK_COMMPATH_IP_ADDR1 --raddr $DK_COMMPATH_IP_ADDR2 --fstag $DK_MOUNT_POINT
		if [ $? -ne 0 ]; then
			echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli resource extend dk --tag $DK_TAG --dest $STANDBY_HOST --mode $DK_MODE --laddr $DK_COMMPATH_IP_ADDR1 --raddr $DK_COMMPATH_IP_ADDR2 --fstag $DK_MOUNT_POINT"
			exit 1
		fi
	fi
fi

# local (ISP)
echo "Checking $ACTIVE_HOST $DK_TAG status"
check_status $DK_TAG ISP
# remote (OSU)
echo "Checking $STANDBY_HOST $DK_TAG status"
check_status_remote $DK_TAG OSU $STANDBY_HOST
}
#
# Create Resource end
#

# main run
case $1 in
	precheck) precheck ;;
	create) create ;;
	*) echo "Usage: $0 (precheck|create)" ; exit 1 ;;
esac


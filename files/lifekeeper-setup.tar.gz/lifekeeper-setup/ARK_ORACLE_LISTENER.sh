#!/bin/bash
#set -x

if [  -f lifekeeper-setup.conf ]; then
	source lifekeeper-setup.conf
else
	echo "$0: lifekeeper-setup.conf not found"
	exit 1
fi
if [ -f COMMON_LIB.sh ]; then
        source COMMON_LIB.sh
else
        echo "$0: COMMON_LIB.sh not found"
        exit 1
fi

#
# Precheck
#
precheck () {
RET=()

echo "$0: Precheck start"

# check required values
echo "checking required config values"
if [ -z "${LISTENER_CONFIG_PATH}" ]; then
	RET+=("LISTENER_CONFIG_PATH : config value is not defined.")
fi
if [ -z "${LISTENER_EXEC_PATH}" ]; then
	RET+=("LISTENER_EXEC_PATH : config value is not defined.")
fi
if [ "$LISTENER_PROTECTION" = "Full" ] || [ "$LISTENER_PROTECTION" = "Intermediate" ] || [ "$LISTENER_PROTECTION" = "Minimal" ] ; then
	: # OK
else
	RET+=("LISTENER_PROTECTION : config value is invalid.")
fi
if [ "$LISTENER_RECOVERY" = "Standard" ] || [ $LISTENER_RECOVERY = "Optional" ]; then
	: # OK
else
	RET+=("LISTENER_RECOVERY : config value is invalid.")
fi
if [ -z "${LISTENER_RUN_USER}" ]; then
	RET+=("LISTENER_RUN_USER : config value is not defined.")
fi
if [ -z "${LISTENER_NAME}" ]; then
	RET+=("LISTENER_NAME : config value is not defined.")
fi
if [ -z "${LISTENER_DEPEND_IP_ADDR}" ]; then
	RET+=("LISTENER_DEPEND_IP_ADDR : config value is not defined.")
fi
if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: requied config settings is missing."
        for ((i = 0; i < ${#RET[@]}; i++)) {
                echo "${RET[i]}"
        }
        exit 1
fi
echo "done."


# check already configured
/opt/LifeKeeper/bin/lkcli resource info --tag LSNR.$LISTENER_NAME |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$0: Tag LSNR.$LISTENER_NAME already created. Skipping this script..."
	exit 0
fi


# check config
echo "checking Listener settings"
if [ ! -f $LISTENER_CONFIG_PATH ]; then
        RET+=("LISTENER_CONFIG_PATH : $LISTENER_CONFIG_PATH file not found.")
fi
grep "SID_LIST_$LISTENER_NAME" $LISTENER_CONFIG_PATH > /dev/null
if [ $? -ne 0 ]; then
	RET+=("$LISTENER_CONFIG_PATH : SID_LIST_$LISTENER_NAME is not defined.")
fi
if [ ! -x "$LISTENER_EXEC_PATH/lsnrctl" ]; then
	RET+=("LISTENER_EXEC_PATH : $LISTENER_EXEC_PATH/lsnrctl can not execute.")
fi
# not good method
ls -l "$LISTENER_EXEC_PATH/lsnrctl" | awk '{print $3}' |grep $LISTENER_RUN_USER  > /dev/null 2>&1
if [ $? -ne 0 ]; then
	RET+=("LISTENER_RUN_USER : $LISTENER_RUN_USER is invalid.")
fi
grep $LISTENER_NAME $LISTENER_CONFIG_PATH | sed 's/ //g' | egrep ^$LISTENER_NAME= > /dev/null 2>&1
if [ $? -ne 0 ]; then
        RET+=("LISTENER_NAME : $LISTENER_NAME is not defined in $LISTENER_CONFIG_PATH.")
fi
grep $LISTENER_DEPEND_IP_ADDR $LISTENER_CONFIG_PATH | sed 's/ //g' | grep -i "HOST=$LISTENER_DEPEND_IP_ADDR" > /dev/null 2>&1
if [ $? -ne 0 ]; then
	RET+=("LISTENER_DEPEND_IP_ADDR : HOST = $LISTENER_DEPEND_IP_ADDR is not defined in $LISTENER_CONFIG_PATH.")
fi
/opt/LifeKeeper/bin/lkcli resource info --tag ip-$LISTENER_DEPEND_IP_ADDR |& grep 'No resource instance has tag' > /dev/null 
if [ $? -eq 0 ]; then
	RET+=("LISTENER_DEPEND_IP_ADDR : IP Resource ip-$LISTENER_DEPEND_IP_ADDR is not defined.")
fi

echo "done."
echo 

# check finish
if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: Precheck completed : failed test"
	for ((i = 0; i < ${#RET[@]}; i++)) {
		echo "${RET[i]}"
	}
        exit 1
else
        echo "$0: Precheck completed"
        exit 0
fi
}
#
# Precheck end
#

#
# Create Resource
#
create () {
# check already configured (local)
/opt/LifeKeeper/bin/lkcli resource info --tag LSNR.$LISTENER_NAME |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$ACTIVE_HOST: Tag LSNR.$LISTENER_NAME already created. Skipping..."
else
	/opt/LifeKeeper/bin/lkcli resource create listener --tag LSNR.$LISTENER_NAME --config $LISTENER_CONFIG_PATH --exe $LISTENER_EXEC_PATH --protection $LISTENER_PROTECTION --recovery $LISTENER_RECOVERY --user $LISTENER_RUN_USER --listener $LISTENER_NAME --iptag ip-$LISTENER_DEPEND_IP_ADDR
	if [ $? -ne 0 ]; then
		echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli resource create listener --tag LSNR.$LISTENER_NAME --config $LISTENER_CONFIG_PATH --exe $LISTENER_EXEC_PATH --protection $LISTENER_PROTECTION --recovery $LISTENER_RECOVERY --user $LISTENER_RUN_USER --listener $LISTENER_NAME --iptag ip-$LISTENER_DEPEND_IP_ADDR"
		exit 1
	fi
fi

# check already configured (remote)
/opt/LifeKeeper/bin/lcdremexec -d $STANDBY_HOST /opt/LifeKeeper/bin/lkcli resource info --tag LSNR.$LISTENER_NAME |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$STANDBY_HOST: Tag LSNR.$LISTENER_NAME already created. Skipping..."
else
	/opt/LifeKeeper/bin/lkcli resource extend listener --tag LSNR.$LISTENER_NAME --dest $STANDBY_HOST
	if [ $? -ne 0 ]; then
		echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli resource extend --tag LSNR.$LISTENER_NAME --dest $STANDBY_HOST"
		exit 1
	fi
fi

# local (ISP)
echo "Checking $ACTIVE_HOST LSNR.$LISTENER_NAME status"
check_status LSNR.$LISTENER_NAME ISP
# remote (OSU)
echo "Checking $STANDBY_HOST LSNR.$LISTENER_NAME status"
check_status_remote LSNR.$LISTENER_NAME OSU $STANDBY_HOST

}
#
# Create Resource end
#

# main run
case $1 in
	precheck) precheck ;;
	create) create ;;
	*) echo "Usage: $0 (precheck|create)" ; exit 1 ;;
esac


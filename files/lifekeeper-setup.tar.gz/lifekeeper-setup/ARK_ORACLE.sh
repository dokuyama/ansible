#!/bin/bash
#set -x

if [  -f lifekeeper-setup.conf ]; then
	source lifekeeper-setup.conf
else
	echo "$0: lifekeeper-setup.conf not found"
	exit 1
fi
if [ -f COMMON_LIB.sh ]; then
        source COMMON_LIB.sh
else
        echo "$0: COMMON_LIB.sh not found"
        exit 1
fi

#
# Precheck
#
precheck () {
RET=()

echo "$0: Precheck start"

# check required values
echo "checking required config values"
if [ -z "${ORACLE_RUN_USER}" ]; then
	RET+=("ORACLE_RUN_USER : config value is not defined.")
fi
if [ -z "${ORACLE_STARTUP_COMMAND}" ]; then
	RET+=("ORACLE_STARTUP_COMMAND : config value is not defined.")
fi
if [ -z "${ORACLE_SID}" ]; then
	RET+=("ORACLE_SID : config value is not defined.")
fi
if [ -z "${ORACLE_LISTENER}" ]; then
	RET+=("ORACLE_LISTENER : config value is not defined.")
fi
# ORACLE_DB_USER, ORACLE_DB_PASSWORD is Optional values

if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: requied config settings is missing."
	for i in "${RET[@]}" ; do echo "$i" ;done
        exit 1
fi
echo "done."


# check already configured
/opt/LifeKeeper/bin/lkcli resource info --tag $ORACLE_SID |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$0: Tag $ORACLE_SID already created. Skipping this script..."
	exit 0
fi


# check config
echo "checking Oracle settings"
# check oracle running
echo "checking Oracle running..."
pgrep ora_pmon_$ORACLE_SID > /dev/null
if [ $? -eq 1 ]; then
	echo "Not running. Try startup oracle...."
	# start oracle
	su - $ORACLE_RUN_USER -c "$ORACLE_STARTUP_COMMAND"
	if [ $? -ne 0 ]; then
		echo "Oracle startup failed"
		exit 1
	fi
fi
ORACLE_HOME=`/opt/LifeKeeper/lkadm/subsys/database/oracle/bin/value_home $ACTIVE_HOST $ORACLE_SID $ORACLE_DB_USER $ORACLE_DB_PASSWORD`
if [ $? -ne 0 ]; then
	echo "check Oracle home directory failed."
	echo "Please check ORACLE_SID, ORACLE_DB_USER, ORACLE_DB_PASSWORD"
	exit 1
fi

/opt/LifeKeeper/bin/lkcli resource info --tag LSNR.$ORACLE_LISTENER |& grep 'No resource instance has tag' > /dev/null
if [ $? -eq 0 ]; then
	RET+=("ORACLE_LISTENER : LSNR.$ORACLE_LISTENER resource is not created.")
fi

echo "done."
echo 

# check finish
if [ ${#RET[@]} -gt 0 ]; then
        echo "$0: Precheck completed : failed test"
	for i in "${RET[@]}" ; do echo "$i" ;done
        exit 1
else
        echo "$0: Precheck completed"
        exit 0
fi
}
#
# Precheck end
#

#
# Create Resource
#
create () {
# check already configured
/opt/LifeKeeper/bin/lkcli resource info --tag $ORACLE_SID |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$ACTIVE_HOST: Tag $ORACLE_SID already created. Skipping..."
else
	/opt/LifeKeeper/bin/lkcli resource create oracle --tag $ORACLE_SID --sid $ORACLE_SID --listener LSNR.$ORACLE_LISTENER
	if [ $? -ne 0 ]; then
		echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli resource create oracle --tag $ORACLE_SID --sid $ORACLE_SID --listener LSNR.$ORACLE_LISTENER"
		exit 1
	fi
fi

# check already configured
/opt/LifeKeeper/bin/lcdremexec -d $STANDBY_HOST /opt/LifeKeeper/bin/lkcli resource info --tag $ORACLE_SID |& grep 'No resource instance has tag' > /dev/null 
if [ $? -ne 0 ]; then
	echo "$STANDBY_HOST: Tag $ORACLE_SID already created. Skipping..."
else
	/opt/LifeKeeper/bin/lkcli resource extend oracle --tag $ORACLE_SID --dest $STANDBY_HOST
	if [ $? -ne 0 ]; then
		echo "ERROR: failed command : /opt/LifeKeeper/bin/lkcli resource extend --tag $ORACLE_SID --dest $STANDBY_HOST"
		exit 1
	fi
fi

# local (ISP)
echo "Checking $ACTIVE_HOST $ORACLE_SID status"
check_status $ORACLE_SID ISP
# remote (OSU)
echo "Checking $STANDBY_HOST $ORACLE_SID status"
check_status_remote $ORACLE_SID OSU $STANDBY_HOST
}
#
# Create Resource end
#

# main run
case $1 in
	precheck) precheck ;;
	create) create ;;
	*) echo "Usage: $0 (precheck|create)" ; exit 1 ;;
esac


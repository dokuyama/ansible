#!/bin/bash

if [  -f lifekeeper-setup.conf ]; then
	source lifekeeper-setup.conf
else
	echo "$0: lifekeeper-setup.conf not found"
	exit 1
fi

#
# precheck
#
precheck () {
RET=()

echo "$0: Precheck start"

# check SELinux
echo "checking SELinux setting"
getenforce | grep Disabled > /dev/null
if [ $? -ne 0 ]; then
        RET+=("SELinux : $ACTIVE_HOST SELinux is not Disabled.")
fi
/opt/LifeKeeper/bin/lcdremexec -d $STANDBY_HOST getenforce | grep Disabled > /dev/null
if [ $? -ne 0 ]; then
        RET+=("SELinux : $STANDBY_HOST SELinux is not Disabled.")
fi

}
#
# precheck end
#

case $1 in
	precheck) precheck ;;
	*) echo "$0: usage (precheck)" ; exit 1 ;;
esac

